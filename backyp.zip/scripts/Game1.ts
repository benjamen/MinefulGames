import { GameSetup } from "./gamesetup";
import {
  world,
  system,
  DimensionLocation,
  BlockPermutation,
  EntityInventoryComponent,
  ItemStack,
  DisplaySlotId,
  Vector3,
} from "@minecraft/server";
import Utilities from "./Utilities.js";
import { Vector3Utils } from "@minecraft/math";
import {
  MinecraftBlockTypes,
  MinecraftDimensionTypes,
  MinecraftEntityTypes,
  MinecraftItemTypes,
} from "@minecraft/vanilla-data";

// Define game-specific logic
export function Game1(log: (message: string, status?: number) => void, location: DimensionLocation) {
  const players = world.getAllPlayers(); // Get all players in the game

  // Instantiate the game setup with specific parameters
  const gameName = "Break the Terracotta";
  const gameDescription = "Destroy as much terracotta as possible to earn points!";
  const timerMinutes = 15; // Set timer to 15 minutes
  const gameMode = "survival"; // Game mode (use actual GameMode enum or string)
  const dayOrNight: "day" | "night" = "day"; // Set to "day" or "night"
  const difficulty: "peaceful" | "easy" | "normal" | "hard" = "easy"; // Set the desired difficulty
  const maxPlayers = 10; // Max number of players (example value)
  const minPlayers = 2; // Min number of players (example value)
  const playerScores = new Map<string, number>(); // Player name (or UUID) -> Score

  // Include dimension in the game area object
  const gameArea = {
    x: location.x,
    y: location.y,
    z: location.z,
    dimension: location.dimension, // Pass the dimension here
  };



    // Continue game setup using the `arenaLocation`
    // For example:


  // Instantiate GameSetup with the updated constructor parameters
  const gameSetup = new GameSetup(
    gameName,
    gameDescription,
    timerMinutes,
    gameMode, // Passing the game mode
    dayOrNight, // Passing the time of day (day or night)
    difficulty, // Passing the difficulty level
  );

  // Start the game with the game setup
  gameSetup.startGame(players, gameArea);

  const START_TICK = 100;
  const ARENA_X_SIZE = 30;
  const ARENA_Z_SIZE = 30;
  const ARENA_X_OFFSET = gameArea.x;
  const ARENA_Y_OFFSET = gameArea.y;
  const ARENA_Z_OFFSET = gameArea.z;
  const ARENA_VECTOR_OFFSET: Vector3 = { x: ARENA_X_OFFSET, y: ARENA_Y_OFFSET, z: ARENA_Z_OFFSET };

  // global variables
  let curTick = 0;
  let score = 0;
  let cottaX = 0;
  let cottaZ = 0;
  let spawnCountdown = 1;

  function initializeBreakTheTerracotta() {
    const overworld = world.getDimension(MinecraftDimensionTypes.Overworld);

    let scoreObjective = world.scoreboard.getObjective("points");
    if (!scoreObjective) {
        log("Creating scoreboard objective 'points'.");
        scoreObjective = world.scoreboard.addObjective("points", "Points");
    }


    // eliminate pesky nearby mobs
    let entities = overworld.getEntities({
      excludeTypes: [MinecraftEntityTypes.Player],
    });

    for (let entity of entities) {
      entity.kill();
    }

    const players = world.getAllPlayers();

    for (const player of players) {
        playerScores.set(player.name, 0); // Reset player score in the map
        if (scoreObjective) {
            scoreObjective.setScore(player, 0); // Reset scoreboard
        }

        const inv = player.getComponent("inventory") as EntityInventoryComponent;
        if (inv.container) {
            inv.container.addItem(new ItemStack(MinecraftItemTypes.DiamondSword));
            inv.container.addItem(new ItemStack(MinecraftItemTypes.Dirt, 64));
        }

        player.teleport(Vector3Utils.add(ARENA_VECTOR_OFFSET, { x: -3, y: 0, z: -3 }), {
            dimension: overworld,
            rotation: { x: 0, y: 0 },
        });
    }}

    world.sendMessage("BREAK THE TERRACOTTA");

    let airBlockPerm = BlockPermutation.resolve(MinecraftBlockTypes.Air);
    let cobblestoneBlockPerm = BlockPermutation.resolve(MinecraftBlockTypes.Cobblestone);

    if (airBlockPerm) {
      Utilities.fillBlock(
        airBlockPerm,
        ARENA_X_OFFSET - ARENA_X_SIZE / 2 + 1,
        ARENA_Y_OFFSET,
        ARENA_Z_OFFSET - ARENA_Z_SIZE / 2 + 1,
        ARENA_X_OFFSET + ARENA_X_SIZE / 2 - 1,
        ARENA_Y_OFFSET + 10,
        ARENA_Z_OFFSET + ARENA_Z_SIZE / 2 - 1
      );
    }

    if (cobblestoneBlockPerm) {
      Utilities.fourWalls(
        cobblestoneBlockPerm,
        ARENA_X_OFFSET - ARENA_X_SIZE / 2,
        ARENA_Y_OFFSET,
        ARENA_Z_OFFSET - ARENA_Z_SIZE / 2,
        ARENA_X_OFFSET + ARENA_X_SIZE / 2,
        ARENA_Y_OFFSET + 10,
        ARENA_Z_OFFSET + ARENA_Z_SIZE / 2
      );
    }


  function gameTick() {
    try {

      if (!world.scoreboard.getObjective("points")) {
            log("Waiting for scoreboard setup...");
            system.run(gameTick);
            return; // Skip this tick if scoreboard isn't ready
      }

      curTick++;

      if (curTick === START_TICK) {
        initializeBreakTheTerracotta();
      }

      if (curTick > START_TICK && curTick % 20 === 0) {
        // no terracotta exists, and we're waiting to spawn a new one.
        if (spawnCountdown > 0) {
          spawnCountdown--;

          if (spawnCountdown <= 0) {
            spawnNewTerracotta();
          }
        } else {
          checkForTerracotta();
        }
      }

      const spawnInterval = Math.ceil(200 / ((score + 1) / 3));
      if (curTick > START_TICK && curTick % spawnInterval === 0) {
        spawnMobs();
      }

      if (curTick > START_TICK && curTick % 29 === 0) {
        addFuzzyLeaves();
      }
    } catch (e) {
      console.warn("Tick error: " + e);
    }

    system.run(gameTick);
  }

  function spawnNewTerracotta() {
    const overworld = world.getDimension(MinecraftDimensionTypes.Overworld);

    // create new terracotta
    cottaX = Math.floor(Math.random() * (ARENA_X_SIZE - 1)) - (ARENA_X_SIZE / 2 - 1);
    cottaZ = Math.floor(Math.random() * (ARENA_Z_SIZE - 1)) - (ARENA_Z_SIZE / 2 - 1);

    world.sendMessage("Creating new terracotta!");
    let block = overworld.getBlock(Vector3Utils.add(ARENA_VECTOR_OFFSET, { x: cottaX, y: 1, z: cottaZ }));

    if (block) {
      block.setPermutation(BlockPermutation.resolve(MinecraftBlockTypes.YellowGlazedTerracotta));
    }
  }

  function checkForTerracotta() {
    const overworld = world.getDimension(MinecraftDimensionTypes.Overworld);

    let block = overworld.getBlock(Vector3Utils.add(ARENA_VECTOR_OFFSET, { x: cottaX, y: 1, z: cottaZ }));

    if (block && !block.permutation.matches(MinecraftBlockTypes.YellowGlazedTerracotta)) {
        // Terracotta block broken, increment player's score
        const players = world.getAllPlayers();
        for (const player of players) {
            const currentScore = playerScores.get(player.name) || 0; // Get current score
            const newScore = currentScore + 1; // Increment by 1
            playerScores.set(player.name, newScore); // Update map
            const scoreObjective = world.scoreboard.getObjective("points"); // Use "points" objective
            
            if (scoreObjective) {
                scoreObjective.setScore(player, newScore); // Update player's score on scoreboard
            }
        }

        world.sendMessage("You broke the terracotta! Creating new terracotta in a few seconds.");
        cottaX = -1;
        cottaZ = -1;
        spawnCountdown = 2;
    }
}

  function spawnMobs() {
    const overworld = world.getDimension(MinecraftDimensionTypes.Overworld);

    // spawn mobs = create 1-2 mobs
    let spawnMobCount = Math.floor(Math.random() * 2) + 1;

    for (let j = 0; j < spawnMobCount; j++) {
      let zombieX = Math.floor(Math.random() * (ARENA_X_SIZE - 2)) - ARENA_X_SIZE / 2;
      let zombieZ = Math.floor(Math.random() * (ARENA_Z_SIZE - 2)) - ARENA_Z_SIZE / 2;

      overworld.spawnEntity(
        MinecraftEntityTypes.Zombie,
        Vector3Utils.add(ARENA_VECTOR_OFFSET, { x: zombieX, y: 1, z: zombieZ })
      );
    }
  }

   function addFuzzyLeaves() {
    const overworld = world.getDimension(MinecraftDimensionTypes.Overworld);

    for (let i = 0; i < 10; i++) {
      const leafX = Math.floor(Math.random() * (ARENA_X_SIZE - 1)) - (ARENA_X_SIZE / 2 - 1);
      const leafY = Math.floor(Math.random() * 10);
      const leafZ = Math.floor(Math.random() * (ARENA_Z_SIZE - 1)) - (ARENA_Z_SIZE / 2 - 1);

      overworld
        .getBlock(Vector3Utils.add(ARENA_VECTOR_OFFSET, { x: leafX, y: leafY, z: leafZ }))
        ?.setPermutation(BlockPermutation.resolve("minecraft:leaves"));
    }
  }

  system.run(gameTick);

  }
